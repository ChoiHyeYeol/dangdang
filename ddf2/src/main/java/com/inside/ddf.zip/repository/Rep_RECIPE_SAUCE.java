package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_RECIPE_SAUCE;

public interface Rep_RECIPE_SAUCE extends JpaRepository<TB_RECIPE_SAUCE, Integer>{

}

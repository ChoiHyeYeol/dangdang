package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_RECIPE_INGR;

public interface Rep_RECIPE_INGR extends JpaRepository<TB_RECIPE_INGR, Integer>{

}

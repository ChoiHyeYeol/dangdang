package com.inside.ddf.code;

public enum GluTypeCode {
	F, //Fast Glucose
	M, //Morning Glucose
	A, //Afternoon Glucose
	E //Evening Glucose

}

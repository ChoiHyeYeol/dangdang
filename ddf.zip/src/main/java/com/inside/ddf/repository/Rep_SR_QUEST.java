package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_SR_QUEST;

public interface Rep_SR_QUEST extends JpaRepository<TB_SR_QUEST, Integer>{

}

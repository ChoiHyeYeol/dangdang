package com.inside.ddf.dto.frontend;

import java.util.List;

import lombok.Data;

@Data
public class GetResponseAllergyDTO {

	List<Integer> answer16;
}

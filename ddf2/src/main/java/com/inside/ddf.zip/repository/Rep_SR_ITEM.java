package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_SR_ITEM;

public interface Rep_SR_ITEM extends JpaRepository<TB_SR_ITEM, Integer>{

}

package com.inside.ddf.code;

public enum GluTypeCode {
	F, //Fast Glucose
	B, //Before
	A //After
	

}

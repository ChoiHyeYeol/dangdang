package com.inside.ddf.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.RequiredArgsConstructor;
import org.springframework.web.reactive.function.client.WebClient;

import com.inside.ddf.dto.req.ChatReq;
import com.inside.ddf.dto.res.ChatRes;
import com.inside.ddf.entity.TB_CHAT_LOG;
import com.inside.ddf.entity.TB_USER;
import com.inside.ddf.repository.Rep_CHAT_LOG;

import jakarta.servlet.http.HttpSession;



@Service
@RequiredArgsConstructor
public class MainService {
	

	private final WebClient fastApiClient;

	@Autowired
	Rep_CHAT_LOG rep_chat;
	
	// 챗봇에 진입했을 때
	public List<TB_CHAT_LOG> getChatLog(TB_USER user) {
		return rep_chat.findAllByUser(user);
	}
	
	
	// 사용자에게 답변용
	public String getExplainChat(ChatReq req, HttpSession session) {
		ChatRes res = getChat(req);
		saveChatContent(res,session);
		return res.getExplanation();
	}
	
	
	//DB에 저장하는 용도
	private void saveChatContent(ChatRes res, HttpSession session) {
		TB_CHAT_LOG chat = new TB_CHAT_LOG();
		chat.setInputTxt(res.getInput());
		chat.setOutputTxt(res.getExplanation());
		TB_USER user = (TB_USER) session.getAttribute("user");
		chat.setUser(user);
		chat = rep_chat.save(chat);
		System.out.println("저장되었습니다.");
		System.out.println(chat.getChatDt());
		
//		System.out.println(rep_chat.findById(1).get().getOutputTxt());
	}
	
    public ChatRes getChat(ChatReq req){
    	ChatRes res =  fastApiClient.post()
                .uri("/api/model/chat/ask")
                .bodyValue(req)
                .retrieve()
                .bodyToMono(ChatRes.class)
                .block(); // 간단히 block(), 서비스 내부에서 reactive 유지도 가능
    	//System.out.println(res.getExplanation());
    	return res;
    }
}

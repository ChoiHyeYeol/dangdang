package com.inside.ddf.dto.frontend;

import java.util.List;

import lombok.Data;

@Data
public class GetResponseComposeDTO {

	List<Integer> answer10;
	int answer11;
	int answer12;
}

package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_SR_RESP;

public interface Rep_SR_RESP extends JpaRepository<TB_SR_RESP, Integer>{

}

package com.inside.ddf.dto.frontend;

import lombok.Data;

@Data
public class GetResponseUnknownPpgDTO {

	int answer6;
	int answer7;
	int answer8;
	int answer9;
}

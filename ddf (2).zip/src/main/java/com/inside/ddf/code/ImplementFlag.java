package com.inside.ddf.code;

public enum ImplementFlag {

	Y, // Yes
    N, // No
}

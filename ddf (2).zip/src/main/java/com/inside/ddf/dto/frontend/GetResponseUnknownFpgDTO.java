package com.inside.ddf.dto.frontend;

import lombok.Data;

@Data
public class GetResponseUnknownFpgDTO {
	int answer3;
	int answer4;
	int answer5;

}

package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_BLOOD_GLU;

public interface Rep_BLOOD_GLU extends JpaRepository<TB_BLOOD_GLU, Integer>{

}

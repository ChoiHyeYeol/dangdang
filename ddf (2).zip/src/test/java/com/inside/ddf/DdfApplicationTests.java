package com.inside.ddf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DdfApplicationTests {

	@Test
	void contextLoads() {
	}

}

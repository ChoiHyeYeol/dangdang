package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_USER;

public interface Rep_USER extends JpaRepository<TB_USER, String>{

}

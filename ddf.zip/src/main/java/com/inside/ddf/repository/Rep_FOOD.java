package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_FOOD;

public interface Rep_FOOD extends JpaRepository<TB_FOOD, String> {

}

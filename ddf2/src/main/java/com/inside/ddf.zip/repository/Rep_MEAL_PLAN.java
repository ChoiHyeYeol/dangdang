package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_MEAL_PLAN;

public interface Rep_MEAL_PLAN extends JpaRepository<TB_MEAL_PLAN, Integer>{

}

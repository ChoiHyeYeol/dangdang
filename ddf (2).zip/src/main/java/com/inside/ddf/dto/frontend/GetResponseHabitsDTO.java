package com.inside.ddf.dto.frontend;

import lombok.Data;

@Data
public class GetResponseHabitsDTO {

	int answer13;
	int answer14;
}

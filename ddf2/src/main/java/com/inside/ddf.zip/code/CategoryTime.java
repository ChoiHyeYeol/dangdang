package com.inside.ddf.code;

public enum CategoryTime {

	B, // Breakfast(아침)
    L, // Lunch(점심)
    D, // Dinner(저녁)
    S  // Snack/기타
}

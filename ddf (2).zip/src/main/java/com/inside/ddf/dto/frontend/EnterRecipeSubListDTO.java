package com.inside.ddf.dto.frontend;

import lombok.Data;

@Data
public class EnterRecipeSubListDTO {

	String method ;
	String category;
}

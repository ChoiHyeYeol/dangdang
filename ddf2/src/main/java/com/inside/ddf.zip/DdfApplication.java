package com.inside.ddf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DdfApplication {

	public static void main(String[] args) {
		SpringApplication.run(DdfApplication.class, args);
	}

}

package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_RECIPE_STEP;

public interface Rep_RECIPE_STEP extends JpaRepository<TB_RECIPE_STEP, Integer>{

}

package com.inside.ddf.code;

public enum QuestType {

	S, //주관식
	O //객관식
}

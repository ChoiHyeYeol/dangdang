package com.inside.ddf.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.inside.ddf.entity.TB_RECIPE;

public interface Rep_RECIPE extends JpaRepository<TB_RECIPE, String>{

}

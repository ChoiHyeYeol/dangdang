package com.inside.ddf.dto.frontend;

import lombok.Data;

@Data
public class GetResponseInfoDTO {

	int answer2;
}
